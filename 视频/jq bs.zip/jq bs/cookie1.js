/*
* document.cookie  = “name=value[;expires=date][;path=path-to-resource][;domain=域名][;secure]”

* */


var cookieObj={
   set:function (o) {
        var  cookieStar=encodeURIComponent(o.name)+"="+encodeURIComponent(o.value);
        if(o.expires){
            cookieStar+=';expires='+o.expires
        }
        if(o.path){
            cookieStar+=";path="+o.path
        }
        if(o.domain){
            cookieStar+=";domain="+o.domain
        }
        if(o.secure){
            cookieStar+=";secure"
        }
        document.cookie=cookieStar

    },
    get:function(n){
       n=encodeURIComponent(n);
       var totalcookie=document.cookie;
       var cookies=totalcookie.split(';');
       for(var i=0,len=cookies.length;i<len;i++)
       {
           var arr=cookies[i].split('=');
              if(n=arr[0])      {
                  return  decodeURIComponent(arr[1])

              }
       }





    }







}