function checkByPid(value){
    var jsonStr=cookieObj.get("datas");
    var jsonObj=Json.parse(jsonStr);
    var exit=false;
    for(var i=0;i<jsonObj.length;i++){
        if(value==jsonObj[i].pid)
            exit=true;
           break;
    }
    return exit;
}
function UpdateDate(obj) {
    var kValue=JSON.stringify(obj);
    cookieObj.set({
        name:'datas',
        value:kValue
    });
   kValue=cookieObj.get("datas");
    return Json.parse(kValue)


}

function getTotalcount() {
    var totalcount=0;
    var jsonStr=cookieObj.get("datas");
    var jsonObj=Json.parse(jsonStr);
    for (var i=0;i<jsonObj.length;i++)
    {
        totalcount+=jsonObj[i].pCount;
    }
    return totalcount;

};
function updataById(id){
    var jsonStr=cookieObj.get("datas");
    var jsonObj=Json.parse(jsonStr);
    for(var i=0;i<jsonObj.length;i++){
        if(id==jsonObj[i].pid){
            jsonObj[i].pCount++;
            break;
        }
    }

    return updateData(jsonObj)

};

function getAllData() {
    var jsonStr = cookieObj.get("datas");
    var listObj = JSON.parse(jsonStr);
    return listObj;
}
function deleteObjByPid(id) {
    var lisObj = getAllData();
    for(var i = 0, len = lisObj.length; i < len; i++) {
        if(lisObj[i].pid == id) {
            lisObj.splice(i, 1);
            break;
        }
    }
    updateData(lisObj);
    return lisObj;
}