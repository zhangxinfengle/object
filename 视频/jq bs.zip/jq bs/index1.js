var ccount = document.getElementById("ccount");
var btns = document.querySelectorAll(".list dl dd button");

var listStr=cookieObj.get('datas');
if(!listStr){
    cookieObj.set({
        name:'datas',
        value:"[]"

    });
    listStr=cookieObj.get("datas")
};
var listArray=JSON.parse(listStr);
var totalCount=0;
for(var i=0;i<listArray.length;i++){
    totalCount+=listArray[i].pCount

}
ccount.innerHTML=totalCount;
for(var i=0;i<btns.length;i++){
    btns[i].onclick=function () {
        var d1=this.parentNode.parentNode;
        var pid=d1.getAttribute("pid");
        var arrs = dl.children;
        if(checkByPid(pid)){

            updataById(pid)
        }else {
            var imgSrc = arrs[0].firstElementChild.src;
            var pName = arrs[1].innerHTML;
            var pDesc = arrs[2].innerHTML;
            var price = arrs[3].firstElementChild.innerHTML;
            var obj={

                pid:pid,
                pImg:imgSrc,
                pName:pName,
                pDesc:pDsc,
                price:price,
                pCound:1

            }
            listStr.push(obj);
            listObj = updateData(listObj);

        }
        ccount.innerHTML = getTotalCount();
    }

}