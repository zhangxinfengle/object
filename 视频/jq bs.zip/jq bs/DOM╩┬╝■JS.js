var EventUtil={
    addHandle:function (element,type,handler) {
        if(element.addEventListener){
            element.addEventListener(type,handler,false)

        }
        else if(element.attachEvent){

            element.attachEvent('on'+type,handler)
        }
        else{
            element['on'+type]=handler;
        }
    },



    removeHandler:function (element,type,handler) {

        if(element.addEventListener)
        {
            element.removeEventListener(type,handler,false)
        }

        else if(element.attachEvent){

            element.detachEvent('on'+type,handler)
        }
        else{
            element['on'+type]=null;
        }
    },
    getEvent:function (event) {
        return event?event:window.event;
    },
    getTarget:function (event) {
        return event.target||event.srcElement;// 事件的目标
        
        
        
        
    },
    preventDefault:function (event) {
        if(event.preventDefault){

            event.preventDefault() ;   //跨游览器的事件对象
        }
        else{
            event.returnValue=false; //阻止默认事件  IE      p
        }
    },
    stopPropagation:function (event ){
        if(event.stopPropagation){
            event.stopPropagation();  //取消冒泡时间    其他游览器
        }
        else{
            event.cancelBubble=true;   //IE  /取消冒泡时间
        }
    },
    getCharCode:function (event) {       //获得键码
        if(typeof event.charCode=='number'){

            return event.charCode;
        }
        else{
            return event.keyCode
        }
    }


};/**
 * Created by asus on 2018/5/30.
 */
