/*
 function ajax1(url,fnsucss,fnfaild) {
 if(window.XMLHttpRequest)
 {
 var ojax=XMLHttpRequest();
 }
 else {
 var oAjax=new ActiveXObject("Microsoft.XMLHTTP");
 }

 ojax.open('GET',url,true);
 ojax.send();
 ojax.onreadystatechange=function () {
 if (ojax.readyState==4)
 {
 if(ojax.status==200)
 {
 fnsucss(ojax.responseText)
 }
 else{
 if (fnfaild)
 fnfaild()
 }
 }

 }

 }*/
/*function  ajax(url,fnsucss,fnfail) {
    if(XMLHttpRequest){
        var ajax=new XMLHttpRequest()

    }
    else{
        var ajax=new ActiveXObject("Microsoft.XMLHTTP")
    }
}
ajax.open('GET',url,true);
ajax.send();
ajax.onreadystatechange=function () {
    if(ajax.readyState==4){
        if(ajax.status>=200&&ajax.status<300||ajax.status==304){
            fnsucss(ajax.responseText)

        }else{
            if(fnfail){

                fnfail()
            }
        }

    }
}*/